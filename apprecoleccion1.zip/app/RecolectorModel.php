<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RecolectorModel extends Model
{
    protected $table = 'recolector';
    protected $primaryKey  = 'idrecolector';
    public $timestamps = false;


}
