@extends('apprecoleccion.home_recoleccion')
@section('content1')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body text-center">
                    <div class="bs-example" data-example-id="simple-jumbotron">
                        <div class="content">
                            <div class="title m-b-ms" align="center">
                                <div class="row">
                                    <div class="col-md-12 text-left" style="background: #fff;height:80px;">
                                        <img src="images/logoDescripcion.jpg" width="20%" >
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                         <div style="margin-top: 10%; opacity: 0.6;"> <img  src="images/logochoneR.png" width="50%" ></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
