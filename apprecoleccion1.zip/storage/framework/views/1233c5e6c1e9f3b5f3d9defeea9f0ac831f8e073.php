<!-- Vista Para la ASIGNACIÓN DE CERTIFICADO CON SUS REQUISITOS -->
<form id="frm_PreguntaEvaluacion" method="POST" action="<?php echo e(url('pregunta_evaluacion')); ?>"  enctype="multipart/form-data" class="form-horizontal form-label-left">
    <?php echo e(csrf_field()); ?>

    <input id="method_PreguntaEvaluacion" type="hidden" name="_method" value="POST">
<!-- MENSAJES PARA CONFIRMACIÓN DE REGISTROS Y ERRORES -->
    <?php if(session()->has('mensajePInfoPreguntaEvaluacion')): ?>
        <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="nombre_menu"></label>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="alert alert-<?php echo e(session('estado')); ?> alert-dismissible fade in" role="alert" style="margin-bottom: 0;">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <strong>Información: </strong> <?php echo e(session('mensajePInfoPreguntaEvaluacion')); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
<!-- FORMULARIO PARA EL REGISTRO -->
    <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="">Pregunta<span class="required">*</span>
        </label>
        <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="chosen-select-content">
                <select data-placeholder="Seleccione una Pregunta" name="pregunta" id="pregunta" required="required" class="chosen-select form-control" tabindex="5">
                <option value=""></option>
                    <?php if(isset($listaPreguntas)): ?>
                        <?php $__currentLoopData = $listaPreguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option class="opcion_pregunta" value="<?php echo e($item->idpregunta); ?>"><?php echo e($item->descripcion); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </div>
        </div>
    </div>

    <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="">Evaluación<span class="required">*</span>
        </label>
        <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="chosen-select-content">
                <select data-placeholder="Seleccione una Evaluación" name="evaluacion" id="evaluacion" required="required" class="chosen-select form-control" tabindex="5">
                <option value=""></option>
                <?php if(isset($listaEvaluacion)): ?>
                    <?php $__currentLoopData = $listaEvaluacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($evaluacion->estado=='E'): ?>
                        <optgroup label="Inicio: <?php echo e($evaluacion->fecha_inicio); ?> ---- Fin: <?php echo e($evaluacion->fecha_fin); ?>">
                            <option class="opcion_evaluacion" value="<?php echo e($evaluacion->idevaluacion); ?>"><?php echo e($evaluacion->nombre); ?></option>
                        <optgroup>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </select>
            </div>
        </div>
    </div>


    <div class="form-group">
        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
            <button type="submit" class="btn btn-success">Guardar</button>
            <button type="button" id="btn_PreguntaEvaluacionCancelar" class="btn btn-warning hidden">Cancelar</button>
        </div>
    </div>
</form>

<div class="ln_solid"></div>
<!-- tabla de los datos INGRESADOS -->
<div class="table-responsive">
    <div class="row">
        <div class="col-sm-12">
            <table id="datatable-fixed-header" class="table table-striped table-bordered">
                <thead>
                <tr role="row">
                    <th class="sorting_desc" tabindex="0" aria-controls="datatable" rowspan="1" colspan="1" aria-label="Name: activate to sort column ascending" aria-sort="descending" style="width: 157px;">Evaluación</th>
                    <th class="sorting" tabindex="0" aria-controls="datatable" rowspan="1" colspan="1" aria-label="Position: activate to sort column ascending" style="width: 259px;">Pregunta</th>
                    <th class="sorting" tabindex="0" aria-controls="datatable" rowspan="1" colspan="1" aria-label="Office: activate to sort column ascending" style="width: 117px;">Acciones</th>
                </tr>
                </thead>

                <tbody>
                <?php if(isset($listaPreguntaEvaluacion)): ?>
                        <?php $__currentLoopData = $listaPreguntaEvaluacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr role="row" class="odd">
                                <td class="sorting_1"><?php echo e($item->evaluacion->nombre); ?></td>
                                <td ><?php echo e($item->pregunta->descripcion); ?></td>

                                <td   class="paddingTR">
                                    <center>
                                    <form method="POST" class="frm_eliminar" action="<?php echo e(url('pregunta_evaluacion/'.encrypt($item->idpregunta_evaluacion))); ?>"  enctype="multipart/form-data">
                                        <?php echo e(csrf_field()); ?> <input type="hidden" name="_method" value="DELETE">
                                        <button type="button" onclick="PreguntaEvaluacion_editar('<?php echo e(encrypt($item->idpregunta_evaluacion)); ?>')" class="btn btn-sm btn-primary marginB0"><i class="fa fa-edit"></i> Editar</button>
                                        <button type="button" class="btn btn-sm btn-danger marginB0" onclick="btn_eliminar(this)"><i class="fa fa-trash"></i> Eliminar</button>
                                    </form>
                                    </center>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\apprecoleccion\resources\views/apprecoleccion/administrador/evaluacionServicios/pregunta_evaluacion.blade.php ENDPATH**/ ?>