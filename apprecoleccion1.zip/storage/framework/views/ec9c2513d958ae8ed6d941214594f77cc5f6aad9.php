<div class="modal fade" id="ventanaModalUsuario" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" style="width:600px;" role="document">
    <div class="modal-content">
	    <div class="modal-header">
	        <label class="modal-title" style="font-size:130%; color:black;">INFORMACIÓN DEL USUARIO</label>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	    </div>
	    <div class="modal-body">
			<div class="row">
		        <div class="col-md-12 profile_details text-center">
		            <div class="well profile_view">
		                <div class="col-sm-12" style="color:black;">
			                <h4 class="brief"><b></b></h4>
			                <hr>
			                <div class="left col-xs-12" style="text-align:center">
			                	<div class="row">
			                		<div class="col-md-6">
									  <h5  style="text-align: left"><span  class="glyphicon glyphicon-credit-card"></span> <strong>DNI:</strong>  </h5>
									  <input type="text" style="border:0;" class="form-control" id="dni">
									</div>
				                	<div class="col-md-6"> 
										<h5 style="text-align: left"><span  class="glyphicon glyphicon-user"></span> <strong>Nombre:</strong></h5>
										<input type="text" style="border:0;" class="form-control" id="nombre">
			                		</div>
			                	</div>
                                <div class="row">
                                    <div class="col-md-6"> 
                                        <h5 style="text-align: left"><span class="glyphicon glyphicon-user"></span> <strong>Usuario:</strong></h5>
										<input type="text" style="border:0;" class="form-control" id="usuario">
									</div>
				                	<div class="col-md-6">
									  <h5  style="text-align: left"><span  class="glyphicon glyphicon-phone"></span> <strong>Celular:</strong></h5>
									  <input type="text" style="border:0;" class="form-control" id="celular">
									</div>
								</div>
			                	<div class="row">
			                		<div class="col-md-12">
									  <h5  style="text-align: left"><span  class="glyphicon glyphicon-map-marker"></span> <strong>Dirección:</strong></h5>
									  <input type="text" style="border:0;" class="form-control" id="direccion">
									</div>
			                	    <div class="col-md-12">
									  <h5  style="text-align: left"><span  class="glyphicon glyphicon-envelope"></span> <strong>Email:</strong></h5>
									  <input type="text" style="border:0;" class="form-control" id="email">
									</div>
			                	</div>
			                </div>
		
		                </div>

		            </div>
				</div>
		    </div>
		</div>

  </div>
</div>
</div>
<?php /**PATH C:\xampp\htdocs\apprecoleccion\resources\views/apprecoleccion/administrador/bandejaOpiniones/ventanaModalUsuario.blade.php ENDPATH**/ ?>