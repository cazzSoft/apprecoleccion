<?php $__env->startSection('content1'); ?>
<!-- Datatables -->
<link href="../vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
   
<link href="../vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">

<div class="" id="RegistroEvaluacionServicios">
        <div class="x_panel">
            <div class="x_title">
                <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><h4><b>GESTIÓN DE LA EVALUACIÓN DE SERVICIOS</b></h4></font></font></h2>
                <ul class="nav navbar-right panel_toolbox">
                    <li style="float: right;"><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                </ul>
                <div class="clearfix"></div>
            </div>
            <div class="x_content x_content_border_mobil">

                <div class="" role="tabpanel" data-example-id="togglable-tabs">

                    <ul id="myTab" class="nav nav-tabs bar_tabs ul_mobil" role="tablist">
                        <li role="presentation" class="<?php if(session()->has('mensajePInfoEvaluacion')): ?> active <?php endif; ?> ">
                            <a href="#evaluacion" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">
                                <font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Crear Evaluación</font></font>
                            </a>
                        </li>
                        <li role="presentation" class="<?php if(session()->has('mensajePInfoPregunta')): ?> active <?php endif; ?> ">
                            <a href="#pregunta" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">
                                <font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Crear Pregunta</font></font>
                            </a>
                        </li>
                        <li role="presentation" class="<?php if(session()->has('mensajePInfoPreguntaEvaluacion')): ?> active <?php endif; ?> ">
                            <a href="#pregunta_evaluacion" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">
                                <font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Asignar Pregunta - Evaluación</font></font>
                            </a>
                        </li>  
    
                    </ul>

                </div>

                <div id="myTabContent" class="tab-content">
                    <div role="tabpanel" class="tab-pane fade <?php if(session()->has('mensajePInfoPregunta')): ?> active in <?php endif; ?>" id="pregunta" aria-labelledby="home-tab">
                    <?php echo $__env->make('apprecoleccion.administrador.evaluacionServicios.pregunta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div role="tabpanel" class="tab-pane fade <?php if(session()->has('mensajeInfoEvaluacion')): ?> active in <?php endif; ?>" id="evaluacion" aria-labelledby="profile-tab">
                    <?php echo $__env->make('apprecoleccion.administrador.evaluacionServicios.evaluacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div role="tabpanel" class="tab-pane fade <?php if(session()->has('mensajePInfoPreguntaEvaluacion')): ?> active in <?php endif; ?>" id="pregunta_evaluacion" aria-labelledby="profile-tab">
                    <?php echo $__env->make('apprecoleccion.administrador.evaluacionServicios.pregunta_evaluacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
            
                </div>

            </div>
        </div>
    
    </div>
<script src="../vendors/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="../vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="<?php echo e(asset('/js/GestionEvaluacionServicios.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('apprecoleccion.home_recoleccion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apprecoleccion\resources\views/apprecoleccion/administrador/evaluacionServicios/GestionEvaluacionServicios.blade.php ENDPATH**/ ?>