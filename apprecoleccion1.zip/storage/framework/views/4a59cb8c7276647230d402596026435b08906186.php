<div class=""  >
    <div class="row " id="divMapa2">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel ">
                <div class="x_title ">
                    <h4><center>GRÁFICA DE LAS RUTAS DE RECOLECCIÓN DE DESECHOS REGISTRADAS</center></h4>
                    <div id="alerta2">
                    </div>
                </div>
                <div class="x_content">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <section class="panel">
                            <div class="panel-body">
                                <div class="project_detail">
                                    <div class="form-group">
                                    <h4>Rutas registradas</h4>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <div class="chosen-select-content">
                                                <select   data-placeholder="Seleccione una ruta..." name="Seleccionar_ruta1 xxx" id="Seleccionar_ruta1" onchange="ShowSelected1()" required="required" class="chosen-select form-control" tabindex="5" >
                                                    <option value=""></option>
                                                        <?php if(isset($listaRutas)): ?>
                                                            <?php $__currentLoopData = $listaRutas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($n->estado_grafica=='SI'): ?>
                                                                    <optgroup label="<?php echo e($n->nombre_ruta); ?>">
                                                                        <option class="opcion_sectores1"  value="<?php echo e($n->idruta); ?>" ><?php echo e($n->descripcion); ?>

                                                                        </option>
                                                                    </optgroup>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <div class="message_wrapper">
                                                <blockquote class="message" id="sectores1">Ninguna ruta seleccionada</blockquote>
                                            </div>
                                            <div class="col-md-4 col-sm-6 col-xs-12">
                                               <form id="frm_Grafica" method="PUT"  enctype="multipart/form-data"  class="form-horizontal form-label-left">
                                                    <?php echo csrf_field(); ?>
                                                      <button class="btn btn-danger btn-block" type="submit" > <i class="fa fa-close" > </i>  Eliminar grafica</button>
                                                 </form>

                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                    <div id="map2" style="height:600px; width:100%" >

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo e(asset('/js/rutaDibujoMapa.js')); ?>"></script>


<?php /**PATH C:\xampp\htdocs\apprecoleccion\resources\views/apprecoleccion/funcionario/ruta/dibujoRuta.blade.php ENDPATH**/ ?>